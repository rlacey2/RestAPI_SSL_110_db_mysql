myApp.controller('LoginCtrl', ['$rootScope','$scope', '$window', '$location', 'UserAuthFactory', 'AuthenticationFactory',  
  function($rootScope, $scope, $window, $location, UserAuthFactory, AuthenticationFactory ) {
		
    $scope.user = {
      username: 'rlacey2@example.com',
      password: 'pass2'
    };
 
    $scope.login = function() {
 
      var username = $scope.user.username;
      var password = $scope.user.password;
 
      if (username !== undefined && password !== undefined) {
        UserAuthFactory.login(username, password).success(function(data) {
          // the user is legit
          AuthenticationFactory.isLogged = true;
          AuthenticationFactory.username = data.user.username;
          AuthenticationFactory.userRole = data.user.role;
					AuthenticationFactory.userId = data.user.id;
 
          $window.sessionStorage.token = data.token;
          $window.sessionStorage.username = data.user.username; // to fetch the user details on refresh
          $window.sessionStorage.userRole = data.user.role;     // to fetch the user details on refresh
          $window.sessionStorage.userId = data.user.id;
					
				//	$rootScope.initialIdle(15);
				
		//	var idleSeconds = 15;
		//IdleProvider.idle(idleSeconds);          // seconds if idle to give warning
		//IdleProvider.timeout(10);                 // warning duration before logging out			
				
					
          $location.path("/");
 
        }).error(function(status) { // login failure
          alert('Oops something went wrong!, is the server running, credentials correct?');
        });
      } else {
        alert('Invalid credentials');
      }
 
    };
 
  }
]);